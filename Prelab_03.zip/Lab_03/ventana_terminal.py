# -*- coding: utf-8 -*-
"""
Created on Mon Aug  2 01:46:14 2021

@author: Jonathan Pu
"""
import serial

com_serial = serial.Serial(port = None, 
                           baudrate = 9600,
                           bytesize= 8,
                           parity = 'N',
                           stopbits= 1)

