# AdafruitIO
# Universidad del Valle de Guatemala
# Digital 2
# Jonathan Pu
# Adafruit IO
# https://io.adafruit.com/

# if Module not Found. Open Terminal/CMD and execute:
# pip3 install Adafruit_IO

from Adafruit_IO import Client, RequestError, Feed

ADAFRUIT_IO_KEY = "aio_XnKI18Zc1tRONAwqwWgVj1Tf1lZv"
ADAFRUIT_IO_USERNAME = "JonnyPu"
aio = Client(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

sensor1 = [10, 20, 5, 12, 100, 255]
sensor2 = [5, 6, 8, 56, 89]

for i in range(0, len(sensor1)):
    sensor1_1 = sensor1[i]
    #Digital Feed
    analog_feed = aio.feeds('sen1')
    aio.send_data(analog_feed.key, sensor1_1)
    digital_data = aio.receive(analog_feed.key)
    print(f'analog signal: {digital_data.value}')

for a in range(0, len(sensor2)):
    sensor2_2 = sensor2[a]
    analog_feed_2 = aio.feeds('sen2')
    aio.send_data(analog_feed_2.key, sensor2_2)
    digital_data_2 = aio.receive(analog_feed_2.key)
    print(f'analog signal: {digital_data_2.value}')
    
    
# #Digital Feed
# analog_feed = aio.feeds('sen1')
# aio.send_data(analog_feed.key, sensor1_1)
# digital_data = aio.receive(analog_feed.key)
# print(f'analog signal: {digital_data.value}')

# analog_feed_2 = aio.feeds('sen2')
# aio.send_data(analog_feed_2.key, sensor2_2)
# digital_data_2 = aio.receive(analog_feed_2.key)
# print(f'analog signal: {digital_data_2.value}')